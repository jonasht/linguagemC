#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct ponto
{
  int x;
  int y;
  int z;
};

struct linha
{
  struct ponto p1;
  struct ponto p2;
};

struct triangulo
{
  struct ponto p1;
  struct ponto p2;
  struct ponto p3;
};

struct quadrilatero
{
  struct ponto p1;
  struct ponto p2;
  struct ponto p3;
  struct ponto p4;
};

int main()
{
  struct linha l1;
  l1.p1.x = 10;
  l1.p1.y =51;
  l1.p1.z = 14;
  l1.p2.x = 10;
  l1.p2.y = 56;
  l1.p2.z = 65;

  struct triangulo t1;
  t1.p1.x = 10;
  t1.p1.y =51;
  t1.p1.z = 14;
  t1.p2.x = 10;
  t1.p2.y = 56;
  t1.p2.z = 65;
  t1.p3.x = 10;
  t1.p3.y = 56;
  t1.p3.z = 65;

  struct quadrilatero q1;
  q1.p1.x = 55;
  q1.p1.y = 5;
  q1.p1.z = 0;
  q1.p2.x = 10;
  q1.p2.y = 56;
  q1.p2.z = 0;
  q1.p3.x = 10;
  q1.p3.y = 10;
  q1.p3.z = 55;
  q1.p4.x = 5;
  q1.p4.y = 10;
  q1.p4.z = 55;

  printf("fim de programa");

  return 0;
}