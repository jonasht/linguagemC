#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct pessoa
{
  char nome[40];
  char endereco[40];
  char cpf[14];
  int idade;
};

struct pessoa mais[5];

int main()
{
  strcpy(mais[0].nome, "Jon joninhas");
  strcpy(mais[0].endereco, "Rua: ladoladodela, 55");
  strcpy(mais[0].cpf, "123.123.123-40");
  mais[0].idade = 55;

  strcpy(mais[1].nome, "Jorge Nava");
  strcpy(mais[1].endereco, "Rua: ladoladodeca, 55");
  strcpy(mais[1].cpf, "153.123.123-40");
  mais[1].idade = 15;

  strcpy(mais[2].nome, "Jonis dejoninhas");
  strcpy(mais[2].endereco, "Rua: ladoladodeca maisla, 55");
  strcpy(mais[2].cpf, "125.125.123-40");
  mais[2].idade = 25;

  strcpy(mais[3].nome, "ondis joninhas");
  strcpy(mais[3].endereco, "Rua: ladoladode lamemo, 555");
  strcpy(mais[3].cpf, "123.123.123-44");
  mais[3].idade = 35;
  
  strcpy(mais[4].nome, "Anne nicolau Bernhards");
  strcpy(mais[4].endereco, "Rua: Wacuhr Fuk, 55");
  strcpy(mais[4].cpf, "123.158.585-10");
  mais[4].idade = 90;

  for(int i = 0 ; i < 5 ; i++)
  {
    printf("pessoa %d\n", i+1);
    printf("Nome: %s\n", mais[i].nome);
    printf("Endereco: %s\n", mais[i].endereco);
    printf("CPF: %s\n", mais[i].cpf);
    printf("Idade: %d\n\n", mais[i].idade);
  }


  
}
