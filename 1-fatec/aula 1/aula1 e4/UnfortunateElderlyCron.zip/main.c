#include <stdio.h>
int main(void) {
  char r = 'n';
  while(r != 's')
  {
    printf("\nquer continuar[s/n]:");
    scanf("%c", &r);
    printf("\nprocessando");
  } 
}