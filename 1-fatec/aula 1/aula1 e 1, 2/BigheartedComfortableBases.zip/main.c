#include <stdio.h>



int main() 
{
	int mes, rf;
  
	printf("qual o mes:");
	scanf("%d", &mes);
  switch(mes)
  {
    case 1:
    rf = 31;
    break;
    case 3:
    rf = 31;
    break;
    case 5:
    rf = 31;
    break;
    case 7:
    rf = 31;
    break;
    case 8:
    rf = 31;
    break;
    case 10:
    rf = 31;
    break;
    case 12:
    rf = 31;
    break;
    case 4:
    rf = 30;
    break;
    case 6:
    rf = 30;
    break;
    case 9:
    rf = 30;
    break;
    case 11:
    rf = 30;
    break;
    case 2:
    rf = 28;
    break;
    default:
      printf("valor incorreto");
      break;
  }
  if (mes <= 12 & mes > 0){
    printf("o mes: %d tem %d dias", mes, rf);
  }


  return 0;


}

