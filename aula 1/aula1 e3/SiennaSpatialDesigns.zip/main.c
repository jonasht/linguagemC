#include <stdio.h>
int main(void) {
  float n = 0;
  int c = 0; 
  float soma = 0;
  do
  {
    printf("numero:");
    scanf("%f", &n);
    if(n != 0)
    {
      soma += n;
      c++;
    }
  } while (n != 0);
  printf("a media eh: %.2f", soma / (float)c);
}