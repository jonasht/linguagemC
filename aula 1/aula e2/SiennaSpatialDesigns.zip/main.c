#include <stdio.h>

int main(void) {
  int n;
  printf("numero:");
  scanf("%d", &n);
  for(int i = n ; i >= 0 ; i-=2)
  {
    printf("%d \n", i);
  }
  return 0;
}