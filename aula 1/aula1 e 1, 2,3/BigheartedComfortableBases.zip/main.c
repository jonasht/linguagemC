#include <stdio.h>



int main() 
{
	int mes, rf = 0;
  
	printf("qual o mes:");
	scanf("%d", &mes);


  switch(mes)
  {
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
      rf +=1;
    case 4:
    case 6:
    case 9:
    case 11:
    rf += 2;
    case 2:
    rf += 28;
  }

  printf("o mes: %d tem %d dias", mes, rf);
  


  return 0;


}

