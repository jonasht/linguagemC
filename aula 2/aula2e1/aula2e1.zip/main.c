#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct pessoa
{
  char nome[30];
  char ender[30];
  char cpf[14];
  int idade;
};

int main() 
{

  struct pessoa joao, lucas, ana;
  
    
    strcpy(joao.nome, "joao jao joanno");
    strcpy(joao.ender, "Rua maratos dola n: 125");
    strcpy(joao.cpf, "123.123.123-04");
    joao.idade = 25;

    strcpy(lucas.nome, " Lucas lucus de lucao");
    strcpy(lucas.ender, "rua da colina azul");
    strcpy(lucas.cpf, "321.321.321-17");
    lucas.idade = 35;

    strcpy(ana.nome, "ana nicolus da nicalinda");
    strcpy(ana.ender, "rua tavateque manheinom");
    strcpy(ana.cpf, "789.456.456-15");
    ana.idade = 20;

  printf("\nnome: %s\n", ana.nome);
  printf("endereco: %s\n", ana.ender);
  printf("CPF: %s\n", ana.cpf);
  printf("Idade: %d\n", ana.idade);


  return 0;
}