#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct ponto
{
  int x, y, z;;
};

int main()
{
  struct ponto pon ;
  pon.x = 5;
  pon.y = 41;
  pon.z = 74;

  printf("\ncordenas tridimencional: x:%d y:%d z:%d\n",pon.x, pon.y, pon.z);

  return 0;
}